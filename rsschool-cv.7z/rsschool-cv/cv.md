 **Romanova Nastassia**
==== 
##### Photo
********* 
![photo](img\sims.png "photo")

##### My Contact Info 
*********
* Address: Mogilev, Belarus
* Phone: +375297410020
* E-mail: [romanova7410020@gmail.com](https://mail.google.com/mail/u/0/#inbox)
* LinkedIn: [romanova7410020](https://mail.google.com/mail/u/0/#inbox)
* GitHub: [romanova7410020](https://mail.google.com/mail/u/0/#inbox)
* CodePen: [romanova7410020](https://mail.google.com/mail/u/0/#inbox)
* Telegram: [romanova7410020](https://mail.google.com/mail/u/0/#inbox) 

##### Summary
********* 
I’m currently working several small web projects. My goal is to learn everything new and exciting. I love to code and coffee. I can(love) spend a lot of time doing what interests me. My core strengths are in problem solving and fast learning.I want to get knowledge and skills that will be enough for employment in a company.

##### Skills
********* 
* HTML
* CSS (Framework Bootstrap, Preprocessor SCSS, BEM methodology).
* JavaScript (Fundamentals,Functional Programming, OOP, Asynchronous JavaScript, ES6+,DOM),JSON.
* React JS, Redux (intermediate level knowledge).
* Version control: Git (remote service GitHub).
* Module Bundlers: Gulp, Webpack.
* Windows OS, Linux(Ubuntu)
* Figma(for web development)
* Editors: Sublime, Brackets, VSCode, PyCharm community.

##### Code examples
********* 
```
function calculate(operation, num1, num2) {
    switch(operation) {
        case 'add':
            return num1 + num2;
        case 'subtract':
            return num1 – num2;
        case 'multiply':
            return num1 * num2;
        case 'divide':
            return num1 / num2;
        default:
            return 'Invalid operation';
    }
}
``` 

##### Education
********* 
* Rs School
    + blabla
* BGSHA
  + blabla

##### Languages
********* 
* Russian - native speaker.
* English - A2
